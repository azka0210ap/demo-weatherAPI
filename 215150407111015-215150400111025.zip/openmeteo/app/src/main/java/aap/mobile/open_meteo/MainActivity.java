package aap.mobile.open_meteo;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements com.android.volley.Response.Listener<JSONObject>, com.android.volley.Response.ErrorListener {

    private static final String JSON_URL = "https://api.open-meteo.com/v1/forecast?latitude=-7.983908&longitude=112.621391&daily=weathercode&current_weather=true&timezone=auto";
    private RequestQueue requestQueue;
    private TextView tvWeather, tvLatitude, tvLongtitude, tvTimeZone, tvTime, tvTemperature, tvWindSpeed;
    private ImageView ivWeather;
    private WeatherAdapter weatherAdapter;
    private RecyclerView rvWeather;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        this.requestQueue = Volley.newRequestQueue(this);

        tvLatitude = findViewById(R.id.tvLatitude);
        tvLongtitude = findViewById(R.id.tvLongtitude);
        tvTimeZone = findViewById(R.id.tvTimeZone);
        tvTime = findViewById(R.id.tvTime);
        tvTemperature = findViewById(R.id.tvTemperature);
        tvWindSpeed = findViewById(R.id.tvWindSpeed);
        tvWeather = findViewById(R.id.tvWeather);
        ivWeather = findViewById(R.id.ivWeather);
        rvWeather = findViewById(R.id.rvWeather);

        getDataFromVolley();
    }
    private void getDataFromVolley() {
        JsonObjectRequest jr = new JsonObjectRequest(
                Request.Method.GET,
                JSON_URL,
                null,
                this,
                this
        );
        this.requestQueue.add(jr);
    }

    @Override
    public void onErrorResponse(VolleyError error) {
        Toast.makeText(this, error.getMessage(), Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onResponse(JSONObject response) {
        try {
            JSONObject crnWeather = response.getJSONObject("current_weather");
            int weatherCode = Integer.parseInt(crnWeather.getString("weathercode"));

            JSONObject daily = response.getJSONObject("daily");
            JSONArray time = daily.getJSONArray("time");
            JSONArray wCode = daily.getJSONArray("weathercode");

            List<String> timeList = new ArrayList<String>();
            List<Integer> wCodeList = new ArrayList<Integer>();

            for (int i = 0; i < time.length(); i++) {
                timeList.add(time.getString(i));
                wCodeList.add(Integer.parseInt(wCode.getString(i)));
            }

            String latitude = response.getString("latitude");
            String longitude = response.getString("longitude");

            ivWeather.setImageResource(Helper.getWeatherImageId(weatherCode));
            tvLatitude.setText("Latitude : " + latitude);
            tvLongtitude.setText("Longtidue : " + longitude);
            tvTimeZone.setText("Time Zone : " + response.getString("timezone"));
            tvTime.setText("Time : "  + crnWeather.getString("time"));
            tvTemperature.setText("Temperature : " + crnWeather.getString("temperature") + "°C");
            tvWindSpeed.setText("Windspeed : " + crnWeather.getString("windspeed") + " km/h");
            tvWeather.setText(Helper.getWeather(weatherCode));

            tvLatitude.setTextColor(Color.parseColor(Helper.getColors(weatherCode)));
            tvLongtitude.setTextColor(Color.parseColor(Helper.getColors(weatherCode)));
            tvTimeZone.setTextColor(Color.parseColor(Helper.getColors(weatherCode)));
            tvTime.setTextColor(Color.parseColor(Helper.getColors(weatherCode)));
            tvTemperature.setTextColor(Color.parseColor(Helper.getColors(weatherCode)));
            tvWindSpeed.setTextColor(Color.parseColor(Helper.getColors(weatherCode)));
            tvWeather.setTextColor(Color.parseColor(Helper.getColors(weatherCode)));

            ConstraintLayout cl = findViewById(R.id.cLayout);
            cl.setBackgroundResource(Helper.getWeatherImageBg(weatherCode));

            weatherAdapter = new WeatherAdapter(this, timeList, wCodeList, weatherCode);
            RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(MainActivity.this);
            rvWeather.setLayoutManager(layoutManager);
            rvWeather.setHasFixedSize(true);
            rvWeather.setAdapter(weatherAdapter);

        } catch (JSONException e) {
            throw new RuntimeException(e);
        }
    }
}