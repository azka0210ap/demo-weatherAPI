package aap.mobile.open_meteo;

public class Helper {
    static int[] clearSKy = {0};
    static int[] partlyCloud = {1,2,3};
    static int[] drizzle = {51,53,55};
    static int[] rain = {61, 63, 65, 80, 81, 82};
    static int[] thunderStorm = {95,96,99};
    static int[][] weatherCodes = {clearSKy, partlyCloud, drizzle, rain, thunderStorm};
    static String[] weathers = {"Clear SKy", "Partly Cloud", "Drizzle", "Rain", "Thunderstorm"};
    static String[] colors = {"#000000", "#000000", "#FFFFFF", "#FFFFFF", "#FFFFFF"};
    static int[] weatherImageId = {R.drawable.clear_sky, R.drawable.partly_cloudy, R.drawable.drizzle, R.drawable.rain, R.drawable.thunderstorm};
    static int[] weatherImageBg = {R.drawable.bg_sky_clear, R.drawable.bg_partly_cloudy, R.drawable.bg_drizzle, R.drawable.bg_rain, R.drawable.bg_thunderstorm};

    public static int getIndex(int weatherCode) {
        for (int i = 0; i < weatherCodes.length; i++) {
            for (int j = 0; j < weatherCodes[i].length; j++) {
                if (weatherCodes[i][j] == weatherCode) {
                    return i;
                }
            }
        }
        return 0;
    }

    public static String getWeather(int weatherCode) {
        return weathers[getIndex(weatherCode)];
    }
    public static int getWeatherImageId(int weatherCode) {
        return weatherImageId[getIndex(weatherCode)];
    }
    public static int getWeatherImageBg(int weatherCode) {
        return weatherImageBg[getIndex(weatherCode)];
    }
    public static String getColors(int weatherCode) {
        return colors[getIndex(weatherCode)];
    }
}
