package aap.mobile.open_meteo;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;


public class WeatherAdapter extends RecyclerView.Adapter<WeatherAdapter.VHWeather> {
    private Context context;
    private List<String> dates;
    private List<Integer> weatherCodes;
    private int currentWeatherCode;

    public WeatherAdapter(Context context, List<String> dates, List<Integer> weatherCodes, int currentWeatherCode) {
        this.context = context;
        this.dates = dates;
        this.weatherCodes = weatherCodes;
        this.currentWeatherCode = currentWeatherCode;
    }

    @NonNull
    @Override
    public VHWeather onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View rowView = LayoutInflater.from(context)
                .inflate(R.layout.row_item, parent, false);

        WeatherAdapter.VHWeather vHWeather = new WeatherAdapter.VHWeather(rowView);
        return vHWeather;
    }

    @Override
    public void onBindViewHolder(@NonNull VHWeather holder, int position) {
        holder.tvDailyWeather.setText(Helper.getWeather(weatherCodes.get(position)));
        holder.tvDailyDate.setText(dates.get(position));
        holder.ivDailyWeather.setImageResource(Helper.getWeatherImageId(weatherCodes.get(position)));
        holder.tvDailyDate.setTextColor(Color.parseColor(Helper.getColors(currentWeatherCode)));
        holder.tvDailyWeather.setTextColor(Color.parseColor(Helper.getColors(currentWeatherCode)));

    }

    @Override
    public int getItemCount() {
        return dates.size();
    }

    class VHWeather extends RecyclerView.ViewHolder{
        private TextView tvDailyWeather, tvDailyDate;
        private ImageView ivDailyWeather;

        public VHWeather(@NonNull View itemView) {
            super(itemView);

            tvDailyWeather = (TextView) itemView.findViewById(R.id.tvDailyWeather);
            tvDailyDate = (TextView) itemView.findViewById(R.id.tvDailyDate);
            ivDailyWeather = (ImageView) itemView.findViewById(R.id.ivDailyWeather);
        }


    }

}
